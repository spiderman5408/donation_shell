<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:49:09
  from '/www/wwwroot/sspanel/resources/views/material/user/lottery.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c551335212db6_81313151',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6feafcb36125211fbe4ad6bcabf077e4eb20fc4a' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/user/lottery.tpl',
      1 => 1549077898,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:dialog.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_5c551335212db6_81313151 (Smarty_Internal_Template $_smarty_tpl) {
?>





<?php $_smarty_tpl->_subTemplateRender('file:user/main.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>







	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<h1 class="content-heading">开心大乐透</h1>
			</div>
		</div>
		<div class="container">
			<section class="content-inner margin-top-no">
				<div class="ui-card-wrap">
					<div class="row">
						<div class="col-lg-12 col-sm-12">
							<div class="card">
								<div class="card-main">
									<div class="card-inner margin-bottom-no">
									<!--	<p class="card-heading">注意!</p>    -->
										<p>幸运大乐透[测试版1.0]</p>
                                      <p>每日开启时间： 22:30</p>
                                      <p>金额抽奖：<?php echo $_smarty_tpl->tpl_vars['price']->value;?>
元/次  每次开奖<?php echo $_smarty_tpl->tpl_vars['price_result']->value;?>
元</p>
                                      <p>流量抽奖：<?php echo $_smarty_tpl->tpl_vars['traffic']->value;?>
M/次  每次开奖<?php echo $_smarty_tpl->tpl_vars['traffic_result']->value;?>
M</p>
                                      <p>玩法说明：每日可参加金额和流量抽奖，即时扣除余额和流量，每日按时开启，TG群组通知</p>
									</div>
									
								</div>
							</div>
						</div>

						<div class="col-lg-12 col-sm-12">
							<div class="card">
								<div class="card-main">
									<div class="card-inner margin-bottom-no">
										<p class="card-heading">金额抽奖[已参与<?php echo $_smarty_tpl->tpl_vars['tj_price']->value;?>
人]<?php if ($_smarty_tpl->tpl_vars['check_if_join_price']->value == 0) {?><button id="submit" type="price" class="btn btn-subscription" style="float:right">参加</button><?php } else { ?><button disabled="disabled" class="btn btn-subscription" style="float:right">已参加</button><?php }?></p>
										<div class="card-table">
											<div class="table-responsive">
												<table class="table">
													<tr>
														<th>幸运观众</th>
														<th>ID</th>
														<th>邮箱</th> 
													</tr>
														<tr>
															<td><?php echo $_smarty_tpl->tpl_vars['name_price']->value;?>
</td>
															<td><?php echo $_smarty_tpl->tpl_vars['id_price']->value;?>
</td>
															<td><?php echo $_smarty_tpl->tpl_vars['email_price']->value;?>
</td>    
														</tr>
												</table>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
						<div class="col-lg-12 col-sm-12">
							<div class="card">
								<div class="card-main">
									<div class="card-inner margin-bottom-no">
										<p class="card-heading">流量抽奖[已参与<?php echo $_smarty_tpl->tpl_vars['tj_traffic']->value;?>
人]<?php if ($_smarty_tpl->tpl_vars['check_if_join_traffic']->value == 0) {?><button id="submit_traffic" type="traffic" class="btn btn-subscription" style="float:right">参加</button><?php } else { ?><button disabled="disabled" class="btn btn-subscription" style="float:right">已参加</button><?php }?></p>
										<div class="card-table">
											<div class="table-responsive">
												<table class="table">
													<tr>
														<th>幸运观众</th>
														<th>ID</th>
														<th>邮箱</th> 
													</tr>
														<tr>
															<td><?php echo $_smarty_tpl->tpl_vars['name_traffic']->value;?>
</td>
															<td><?php echo $_smarty_tpl->tpl_vars['id_traffic']->value;?>
</td>
															<td><?php echo $_smarty_tpl->tpl_vars['email_traffic']->value;?>
</td>    
														</tr>
												</table>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
						<?php $_smarty_tpl->_subTemplateRender('file:dialog.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
					</div>
				</div>
			</section>
		</div>
	</main>







<?php $_smarty_tpl->_subTemplateRender('file:user/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
echo '<script'; ?>
>
    $(document).ready(function () {
        function submit() {
			$("#result").modal();
            $("#msg").html("正在提交。");
            $.ajax({
                type: "POST",
                url: "/user/lottery_join",
                dataType: "json",
                data: {
                    enable: 1,
					type: $("#submit").attr("type")
                },
                success: function (data) {
                    if (data.ret) {
                        $("#result").modal();
                        $("#msg").html(data.msg);
                        window.setTimeout("location.href='/user/lottery'", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
                    } else {
                        $("#result").modal();
                        $("#msg").html(data.msg);
                    }
                },
                error: function (jqXHR) {
                    $("#msg-error").hide(10);
                    $("#msg-error").show(100);
                    $("#msg-error-p").html("发生错误：" + jqXHR.status);
                }
            });
        }
		
        $("#submit").click(function () {
            submit();
        });
    });
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    $(document).ready(function () {
        function submit_traffic() {
			$("#result").modal();
            $("#msg").html("正在提交。");
            $.ajax({
                type: "POST",
                url: "/user/lottery_join",
                dataType: "json",
                data: {
                    enable: 1,
					type: $("#submit_traffic").attr("type")
                },
                success: function (data) {
                    if (data.ret) {
                        $("#result").modal();
                        $("#msg").html(data.msg);
                        window.setTimeout("location.href='/user/lottery'", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
                    } else {
                        $("#result").modal();
                        $("#msg").html(data.msg);
                    }
                },
                error: function (jqXHR) {
                    $("#msg-error").hide(10);
                    $("#msg-error").show(100);
                    $("#msg-error-p").html("发生错误：" + jqXHR.status);
                }
            });
        }
		
        $("#submit_traffic").click(function () {
            submit_traffic();
        });
    });
<?php echo '</script'; ?>
><?php }
}
