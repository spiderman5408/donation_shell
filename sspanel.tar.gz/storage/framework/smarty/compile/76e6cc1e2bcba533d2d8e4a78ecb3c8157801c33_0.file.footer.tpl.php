<?php
/* Smarty version 3.1.34-dev-5, created on 2018-12-02 18:28:10
  from '/www/wwwroot/sspanel/resources/views/material/admin/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c03b3badffc04_05905604',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '76e6cc1e2bcba533d2d8e4a78ecb3c8157801c33' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/admin/footer.tpl',
      1 => 1543557925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:analytics.tpl' => 1,
  ),
),false)) {
function content_5c03b3badffc04_05905604 (Smarty_Internal_Template $_smarty_tpl) {
?>	<footer class="ui-footer" style="position:relative">
		<div class="container">
			&copy; <?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
  <a href="/staff">STAFF</a> <?php if ($_smarty_tpl->tpl_vars['config']->value["enable_analytics_code"] == 'true') {
$_smarty_tpl->_subTemplateRender('file:analytics.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
		</div>
	</footer>

	<!-- js -->
	<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@3.3.1"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/datatables.net@1.10.19"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="//cdn.jsdelivr.net/gh/DataTables/DataTables@1.10.19/media/js/dataTables.material.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/base.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/project.js"><?php echo '</script'; ?>
>
	
</body>
</html>
<?php }
}
