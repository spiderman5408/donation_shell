<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:48:34
  from '/www/wwwroot/sspanel/resources/views/material/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c55131224ab07_50385894',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5f29f8851f474facad342233b43ecd354bc6d512' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/index.tpl',
      1 => 1543730565,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c55131224ab07_50385894 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE HTML> 
<!--
	Dimension by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?php if ($_smarty_tpl->tpl_vars['config']->value['appName'] == '跑路') {
echo '<script'; ?>
>window.location.href='<?php echo $_smarty_tpl->tpl_vars['config']->value["baseUrl"];?>
/paolu.html';<?php echo '</script'; ?>
>
<?php }?>
<html>
	<head>
		<title><?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
</title>
        <meta name="keywords" content=""/>
        <meta name="description" content=""/>
        <meta charset="utf-8" />
        <link rel="shortcut icon" href="/favicon.ico"/>
        <link rel="bookmark" href="/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
		<link rel="stylesheet" href="/assets/css/main.css"/>
        <noscript><link rel="stylesheet" href="/assets/css/noscript.css" /></noscript>   
  </head>
  
       <body>
			<div id="wrapper">
              <!--首页开始-->
					<header id="header">
						
                       <?php if ($_smarty_tpl->tpl_vars['user']->value->isLogin) {?>
						<div class="content">
							<div class="inner">
                                  <p>用户：<code><?php echo $_smarty_tpl->tpl_vars['user']->value->user_name;?>
</code>
                                    等级：<?php if ($_smarty_tpl->tpl_vars['user']->value->class != 0) {?>
											<code>VIP<?php echo $_smarty_tpl->tpl_vars['user']->value->class;?>
</code>
                                          <?php } else { ?>
                                             <code>免费</code>
                                              <?php }?>
                                    过期时间：<?php if ($_smarty_tpl->tpl_vars['user']->value->class_expire != "1989-06-04 00:05:00") {?>
											    <code><?php echo $_smarty_tpl->tpl_vars['user']->value->class_expire;?>
</code>
                                          <?php } else { ?>
                                              <code>不过期</code>
                                              <?php }?></p>
                                  <p>总流量：<code><?php echo $_smarty_tpl->tpl_vars['user']->value->enableTraffic();?>
</code>
                                  已用流量：<code><?php echo $_smarty_tpl->tpl_vars['user']->value->usedTraffic();?>
</code>
                                  剩余流量：<code><?php echo $_smarty_tpl->tpl_vars['user']->value->unusedTraffic();?>
</code></p>
                          </div>
                      </div>	
					  	<nav>
							<ul>
                                <li><a href="#1">简介</a></li>
					            <li><a href="/user">用户中心</a></li>
								<li><a href="/user/logout">退出登录</a></li>
								<li><a href="#5">下载</a></li>
                        </ul>
						</nav>
                              <?php } else { ?>
                              <div class="content">
							<div class="inner">
								<h1><?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
</h1>
								<!--
								如果想自定义文本请删除下面这段script代码,格式为
								<p>自定义文本</p>
								-->
                              <p>拥有GIA、IIJ、HKBN、HKT、GCP、AZURE、AWS、阿里云、软银CN2等多条知名线路。</p>
                              </div>
                          </div>
                    	
                              <nav>
							<ul>
                               <li><a href="#1">简介</a></li>
								<li><a href="/auth/login">登录</a></li>
								<li><a href="/auth/register">注册</a></li>
                              	<li><a href="#5">下载</a></li>
                              
                           </ul>
						</nav>
                              <?php }?>

              </header> 
             <!--首页结束-->
					<div id="main">
                      <!--标签1开始-->
                      <article id="1">
                      <h2 class="major">简介</h2>
                      <p>拥有GIA、IIJ、HKBN、HKT、GCP、Azure、AWS、阿里云、软银CN2等多条知名线路。</p></article>
					  <!--
					  简介修改示例: 
					  <p> 123</p>
					  一个  <p> 123</p>  为一行，请不要删除 </article>
					  -->
                     <!--标签4开始-->
                      <article id="4">
								<h2 class="major">联系我们</h2>
								<ul class="icons">
                                   <p>此处填写联系方式</p>
                                    <li>
                                      <a target="_blank" href="#" class="icon fa-facebook">
									 <!-- 请在fontawesome.com寻找替换图标 href替换链接 -->
                                      <span class="label">Facebook</span>
                                      </a>
                                    </li>
                                  </ul>
                                  </article>
                      <!--标签5开始-->
	                        <article id="5">
							<h2 class="major">软件下载</h2>
							<ul>
							  <li><a href="/ssr-download/ssr-win.7z" class="icon fa-windows"><span class="label"></span> Windows</a></li>
							  <li><a href="/ssr-download/ssr-mac.dmg" class="icon fa-apple"><span class="label">Mac</span> Mac</a></li>
							  <li><a href="/ssr-download/ssr-android.apk" class="icon fa-android"><span class="label">Android</span> Android</a></li>
							  <li><a href="#ios" class="icon fa-apple"><span class="label">iOS</span> iOS</a></li>
                              <li><a href="/ssr-download/SSTap.7z" class="icon fa-gamepad"><span class="label">Win游戏专用</span> Win游戏专用</a></li>
                            
	                         </ul>
                             </article>
                            <!--标签5开始-->
                      	<article id="login">  
		
								<h2 class="major">登录</h2>
								<form method="post" action="javascript:void(0);">
									<div class="field half first">
										<label for="email2">邮箱</label>
										<input type="text" name="Email" id="email2" />
									</div>
									<div class="field half">
										<label for="passwd">密码</label>
										<input type="password" name="Password" id="passwd" />
									</div>
									
									<ul class="actions">
										<li><input id="login" type="submit" value="登录" class="special" /></li>
										<li><input type="reset" value="清空" /></li>
									</ul>
								</form>
						

                             	<div class="field half">
											<input value="week" id="remember_me" name="remember_me" type="checkbox" checked>
											<label for="remember_me">记住我</label>
								</div>


								<br>

								<div id="result" role="dialog" >
													<p color class="h5 margin-top-sm text-black-hint" id="msg"></p>
								</div>
						</article> 
                      <!--全部标签结束-->
                      
                              </div>
                     <!-- 版权底部 -->
                      <footer id="footer">
                   <p class="copyright">&copy;2017-<?php echo date("Y");?>
 <?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
</p>
                      </footer>
              <!-- 版权结束 -->
			 </div>
                <!-- BG -->
			<div id="bg"></div>
	        	<!-- Scripts -->
			<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@1.11.3"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/gh/ajlkn/skel@3.0.1/dist/skel.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="/assets/js/util.js"><?php echo '</script'; ?>
>
         <?php echo '<script'; ?>
 src="/assets/js/main.js"><?php echo '</script'; ?>
>
	     
	</body>
</html>
<?php }
}
