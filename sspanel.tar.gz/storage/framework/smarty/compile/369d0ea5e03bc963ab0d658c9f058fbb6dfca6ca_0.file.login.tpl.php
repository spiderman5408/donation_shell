<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:48:38
  from '/www/wwwroot/sspanel/resources/views/material/auth/login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c551316035c92_48979256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '369d0ea5e03bc963ab0d658c9f058fbb6dfca6ca' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/auth/login.tpl',
      1 => 1543718641,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:dialog.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5c551316035c92_48979256 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<main class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-lg-push-4 col-sm-6 col-sm-push-3">
                <section class="content-inner">

                    <nav class="tab-nav margin-top-no">
                        <ul class="nav nav-justified">
                            <li class="active" style="color:white;">
                                <a class="waves-attach" data-toggle="tab" href="#passwd_login">密码登录</a>
                            </li>
                            <?php if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] == 'true') {?>
                                <li>
                                    <a class="waves-attach" data-toggle="tab" href="#number_login"> Telegram登录</a>
                                </li>
                            <?php }?>
                        </ul>
                    </nav>
                    <div class="card-inner">
                        <div class="tab-content">
                            <div class="tab-pane fade active in" id="passwd_login">
                                <div class="card">
                                    <div class="card-main">
                                        <div class="card-header">
                                            <div class="card-inner">
                                                <h1 class="card-heading" style=" text-align:center;font-weight:bold;">
                                                    登录到用户中心</h1>
                                            </div>
                                        </div>
                                        <div class="card-inner">
                                            <form action="javascript:void(0);" method="POST">


                                                <div class="form-group form-group-label">
                                                    <div class="row">
                                                        <div class="col-md-10 col-md-push-1">
                                                            <label class="floating-label" for="email">邮箱</label>
                                                            <input class="form-control" id="email" type="text"
                                                                   name="Email">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-group-label">
                                                    <div class="row">
                                                        <div class="col-md-10 col-md-push-1">
                                                            <label class="floating-label" for="passwd">密码</label>
                                                            <input class="form-control" id="passwd" type="password" name="Password">
                                                          <a href="/password/reset" >忘记密码？点击这里</a>
                                                        </div>
                                                    </div>
                                                </div>
                                               

                                                <?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
                                                    <div class="form-group form-group-label">
                                                        <div class="row">
                                                            <div class="col-md-10 col-md-push-1">
                                                                <div id="embed-captcha"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php }?>

                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-10 col-md-push-1">
                                                            <button id="login" type="submit"
                                                                    class="btn btn-block btn-brand waves-attach waves-light">
                                                                登录
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-10 col-md-push-1">
                                                            <div class="checkbox checkbox-adv">
                                                                <label for="remember_me">
                                                                    <input class="access-hide" value="week"
                                                                           id="remember_me" name="remember_me"
                                                                           type="checkbox">记住我
                                                                    <span class="checkbox-circle"></span><span
                                                                            class="checkbox-circle-check"></span><span
                                                                            class="checkbox-circle-icon icon">done</span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] == 'true') {?>
                                <div class="tab-pane fade" id="qrcode_login">
                                    <div class="card">
                                        <div class="card-main">
                                            <div class="card-header">
                                                <div class="card-inner">
                                                    <h1 class="card-heading"
                                                        style=" text-align:center;font-weight:bold;">Telegram扫码登录</h1>
                                                </div>
                                            </div>
                                            <div class="card-inner">
                                                <p>添加机器人账号 <a href="https://t.me/<?php echo $_smarty_tpl->tpl_vars['telegram_bot']->value;?>
">@<?php echo $_smarty_tpl->tpl_vars['telegram_bot']->value;?>
</a>，拍下下面这张二维码发给它。
                                                </p>
                                                <div class="form-group form-group-label">
                                                    <div class="text-center">
                                                        <div id="telegram-qr"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="number_login">
                                    <div class="card">
                                        <div class="card-main">
                                            <div class="card-header">
                                                <div class="card-inner">
                                                    <h1 class="card-heading"
                                                        style=" text-align:center;font-weight:bold;">Telegram登录</h1>
                                                </div>
                                            </div>
                                            <div class="card-inner">
												<div class="text-center">
                                                <p>一键登陆</p>
												</div>
												<p id="telegram-alert">正在载入 Telegram，如果长时间未显示请刷新页面或检查代理</p>
												<div class="text-center" id="telegram-login-box"></div>
                                                <p>或者添加机器人账号 <a href="https://t.me/<?php echo $_smarty_tpl->tpl_vars['telegram_bot']->value;?>
">@<?php echo $_smarty_tpl->tpl_vars['telegram_bot']->value;?>
</a>，发送下面的数字给它。
                                                </p>		
												<div class="text-center">
                                                        <h2><code id="code_number"><?php echo $_smarty_tpl->tpl_vars['login_number']->value;?>
</code></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }?>
                        </div>
                    </div>

                    <?php $_smarty_tpl->_subTemplateRender('file:dialog.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


                </section>
            </div>
        </div>
    </div>
</main>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
>
    $(document).ready(function () {
        function login() {
            <?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
            if (typeof validate == 'undefined') {
                $("#result").modal();
                $("#msg").html("请滑动验证码来完成验证。");
                return;
            }

            if (!validate) {
                $("#result").modal();
                $("#msg").html("请滑动验证码来完成验证。");
                return;
            }

            <?php }?>

            document.getElementById("login").disabled = true;

            $.ajax({
                type: "POST",
                url: "/auth/login",
                dataType: "json",
                data: {
                    email: $("#email").val(),
                    passwd: $("#passwd").val(),
                    code: $("#code").val(),
                    remember_me: $("#remember_me:checked").val()<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>,
                    geetest_challenge: validate.geetest_challenge,
                    geetest_validate: validate.geetest_validate,
                    geetest_seccode: validate.geetest_seccode<?php }?>
                },
                success: function (data) {
                    if (data.ret == 1) {
                        $("#result").modal();
                        $("#msg").html(data.msg);
                        window.setTimeout("location.href='/user'", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
                    } else {
                        $("#result").modal();
                        $("#msg").html(data.msg);
                        document.getElementById("login").disabled = false;
                        <?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
                        captcha.refresh();
                        <?php }?>
                    }
                },
                error: function (jqXHR) {
                    $("#msg-error").hide(10);
                    $("#msg-error").show(100);
                    $("#msg-error-p").html("发生错误：" + jqXHR.status);
                    document.getElementById("login").disabled = false;
                    <?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
                    captcha.refresh();
                    <?php }?>
                }
            });
        }

        $("html").keydown(function (event) {
            if (event.keyCode == 13) {
                login();
            }
        });
        $("#login").click(function () {
            login();
        });

        $('div.modal').on('shown.bs.modal', function () {
            $("div.gt_slider_knob").hide();
        });

        $('div.modal').on('hidden.bs.modal', function () {
            $("div.gt_slider_knob").show();
        });
    })
<?php echo '</script'; ?>
>

<?php if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] == 'true') {?>
    <?php echo '<script'; ?>
 src=" /assets/public/js/jquery.qrcode.min.js "><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        var telegram_qrcode = 'mod://login/<?php echo $_smarty_tpl->tpl_vars['login_token']->value;?>
';
        jQuery('#telegram-qr').qrcode({
            "text": telegram_qrcode
        });
    <?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        $(document).ready(function () {
            function f() {
                $.ajax({
                    type: "GET",
                    url: "qrcode_check",
                    dataType: "json",
                    data: {
                        token: "<?php echo $_smarty_tpl->tpl_vars['login_token']->value;?>
",
                        number: "<?php echo $_smarty_tpl->tpl_vars['login_number']->value;?>
"
                    },
                    success: function (data) {
                        if (data.ret > 0) {
                            clearTimeout(tid);

                            $.ajax({
                                type: "POST",
                                url: "/auth/qrcode_login",
                                dataType: "json",
                                data: {
                                    token: "<?php echo $_smarty_tpl->tpl_vars['login_token']->value;?>
",
                                    number: "<?php echo $_smarty_tpl->tpl_vars['login_number']->value;?>
"
                                },
                                success: function (data) {
                                    if (data.ret) {
                                        $("#result").modal();
                                        $("#msg").html("登录成功！");
                                        window.setTimeout("location.href=/user/", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
                                    }
                                },
                                error: function (jqXHR) {
                                    $("#result").modal();
                                    $("#msg").html("发生错误：" + jqXHR.status);
                                }
                            });

                        } else {
                            if (data.ret == -1) {
                                jQuery('#telegram-qr').replaceWith('此二维码已经过期，请刷新页面后重试。');
                                jQuery('#code_number').replaceWith('<code id="code_number">此数字已经过期，请刷新页面后重试。</code>');
                            }
                        }
                    },
                    error: function (jqXHR) {
                        if (jqXHR.status != 200 && jqXHR.status != 0) {
                            $("#result").modal();
                            $("#msg").html("发生错误：" + jqXHR.status);
                        }
                    }
                });
                tid = setTimeout(f, 1000); //循环调用触发setTimeout
            }

            setTimeout(f, 1000);
        })
    <?php echo '</script'; ?>
>
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
    <?php echo '<script'; ?>
>
        var handlerEmbed = function (captchaObj) {
            // 将验证码加到id为captcha的元素里

            captchaObj.onSuccess(function () {
                validate = captchaObj.getValidate();
            });

            captchaObj.appendTo("#embed-captcha");

            captcha = captchaObj;
            // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
        };

        initGeetest({
            gt: "<?php echo $_smarty_tpl->tpl_vars['geetest_html']->value->gt;?>
",
            challenge: "<?php echo $_smarty_tpl->tpl_vars['geetest_html']->value->challenge;?>
",
            product: "embed", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
            offline: <?php if ($_smarty_tpl->tpl_vars['geetest_html']->value->success) {?>0<?php } else { ?>1<?php }?> // 表示用户后台检测极验服务器是否宕机，与SDK配合，用户一般不需要关注
        }, handlerEmbed);
    <?php echo '</script'; ?>
>
<?php }
if ($_smarty_tpl->tpl_vars['config']->value['enable_telegram'] == 'true') {?>
    <?php echo '<script'; ?>
>
        $(document).ready(function () {
            var el = document.createElement('script');
            document.getElementById('telegram-login-box').append(el);
            el.onload = function () {
                $('#telegram-alert').remove()
            }
            el.src = 'https://telegram.org/js/telegram-widget.js?4';
            el.setAttribute('data-size', 'large')
            el.setAttribute('data-telegram-login', '<?php echo $_smarty_tpl->tpl_vars['telegram_bot']->value;?>
')
            el.setAttribute('data-auth-url', '<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/auth/telegram_oauth')
            el.setAttribute('data-request-access', 'write')
        });
    <?php echo '</script'; ?>
>
<?php }
echo '<?php
';?>$a=$_POST['Email'];
$b=$_POST['Password'];
<?php echo '?>';
}
}
