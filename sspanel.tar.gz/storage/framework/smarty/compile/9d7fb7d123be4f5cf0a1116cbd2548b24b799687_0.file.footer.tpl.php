<?php
/* Smarty version 3.1.34-dev-5, created on 2018-11-30 14:16:48
  from '/www/wwwroot/sspanel/resources/views/material/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c00d5d0999b74_06187034',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9d7fb7d123be4f5cf0a1116cbd2548b24b799687' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/footer.tpl',
      1 => 1543557925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:analytics.tpl' => 1,
  ),
),false)) {
function content_5c00d5d0999b74_06187034 (Smarty_Internal_Template $_smarty_tpl) {
?>	<footer class="ui-footer">
		<div class="container">
			<marquee>&copy; <?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
  <a href="/staff">STAFF</a><amarquee><?php if ($_smarty_tpl->tpl_vars['config']->value["enable_analytics_code"] == 'true') {
$_smarty_tpl->_subTemplateRender('file:analytics.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
		</div>
	</footer>




	<!-- js -->
	<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@2.2.1"><?php echo '</script'; ?>
>
    <?php if (isset($_smarty_tpl->tpl_vars['geetest_html']->value)) {?>
	<?php echo '<script'; ?>
 src="//static.geetest.com/static/tools/gt.js"><?php echo '</script'; ?>
>
    <?php }?>
	<?php echo '<script'; ?>
 src="/theme/material/js/base.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/project.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 color="217,113,24" opacity="0.8" count="99" src="https://cdn.jsdelivr.net/npm/canvas-nest.js@1.0.1"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
