<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:48:38
  from '/www/wwwroot/sspanel/resources/views/material/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c55131604c255_44376180',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9d7fb7d123be4f5cf0a1116cbd2548b24b799687' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/footer.tpl',
      1 => 1543817953,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:analytics.tpl' => 1,
  ),
),false)) {
function content_5c55131604c255_44376180 (Smarty_Internal_Template $_smarty_tpl) {
?>	<footer class="">
		<div class="">
			<?php if ($_smarty_tpl->tpl_vars['config']->value["enable_analytics_code"] == 'true') {
$_smarty_tpl->_subTemplateRender('file:analytics.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
		</div>
	</footer>




	<!-- js -->
	<?php echo '<script'; ?>
 src="/theme/material/js/jquery.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="//static.geetest.com/static/tools/gt.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="https://js.users.51.la/19732545.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/base.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/project.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 type="text/javascript" color="217,113,24" opacity="0.8" count="99" src="https://cdn.jsdelivr.net/npm/canvas-nest.js@1.0.1"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
