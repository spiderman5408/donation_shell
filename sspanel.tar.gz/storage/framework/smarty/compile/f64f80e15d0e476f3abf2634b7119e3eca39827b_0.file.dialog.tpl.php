<?php
/* Smarty version 3.1.34-dev-5, created on 2018-11-30 14:16:48
  from '/www/wwwroot/sspanel/resources/views/material/dialog.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c00d5d0996a37_56802534',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f64f80e15d0e476f3abf2634b7119e3eca39827b' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/dialog.tpl',
      1 => 1543557925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c00d5d0996a37_56802534 (Smarty_Internal_Template $_smarty_tpl) {
?><div aria-hidden="true" class="modal modal-va-middle fade" id="result" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-xs">
		<div class="modal-content">
			<div class="modal-inner">
				<p class="h5 margin-top-sm text-black-hint" id="msg"></p>
			</div>
			<div class="modal-footer">
				<p class="text-right"><button class="btn btn-flat btn-brand-accent waves-attach" data-dismiss="modal" type="button" id="result_ok">知道了</button></p>
			</div>
		</div>
	</div>
</div><?php }
}
