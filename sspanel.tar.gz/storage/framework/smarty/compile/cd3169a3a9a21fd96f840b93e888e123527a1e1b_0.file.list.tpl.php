<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:57:01
  from '/www/wwwroot/sspanel/resources/views/material/user/list.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c55150d124155_82120711',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd3169a3a9a21fd96f840b93e888e123527a1e1b' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/user/list.tpl',
      1 => 1549079817,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_5c55150d124155_82120711 (Smarty_Internal_Template $_smarty_tpl) {
?>





<?php $_smarty_tpl->_subTemplateRender('file:user/main.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>







	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<h1 class="content-heading">排行榜</h1>
			</div>
		</div>
		<div class="container">
			<section class="content-inner margin-top-no">
				<div class="ui-card-wrap">
					<div class="row">
						<div class="col-lg-12 col-sm-12">
							<div class="card">
								<div class="card-main">
									<div class="card-inner margin-bottom-no">
									<!--	<p class="card-heading">注意!</p>    -->
										<p>此处只展示前10名排行榜</p>
									</div>
									
								</div>
							</div>
						</div>

						<div class="col-lg-12 col-sm-12">
							<div class="card">
								<div class="card-main">
									<div class="card-inner margin-bottom-no">
										<p class="card-heading">流量使用排行榜</p>
										<div class="card-table">
											<div class="table-responsive">
												<table class="table">
													<tr>
														<th>用户ID</th>
														<th>用户昵称</th>
                                                        <th>用户等级</th>
														<th>已使用流量(GB)</th>
													</tr>
													<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['list']->value, 'single');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['single']->value) {
?>

														<tr>
															<td><?php echo $_smarty_tpl->tpl_vars['single']->value->id;?>
</td>
															<td><?php echo ($_smarty_tpl->tpl_vars['single']->value->user_name).('**');?>
</td>
                                                            <td><?php echo $_smarty_tpl->tpl_vars['single']->value->class;?>
</td>
															<td><?php ob_start();
echo $_smarty_tpl->tpl_vars['single']->value->last_day_t;
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1/sprintf("%.2f",1073741824);?>
</td>  
														</tr>
													<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
												</table>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
                      
                      <div class="col-lg-12 col-sm-12">
							<div class="card">
								<div class="card-main">
									<div class="card-inner margin-bottom-no">
										<p class="card-heading">邀请人数排行榜</p>
										<div class="card-table">
											<div class="table-responsive">
												<table class="table">
													<tr>
														<th>用户ID</th>
														<th>用户昵称</th>
                                                        <th>用户等级</th>
														<th>已邀请人数</th>
													</tr>
													<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['inviteList']->value, 'single');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['single']->value) {
?>

														<tr>
															<td><?php echo $_smarty_tpl->tpl_vars['single']->value->id;?>
</td>
															<td><?php echo ($_smarty_tpl->tpl_vars['single']->value->user_name).('**');?>
</td>
                                                            <td><?php echo $_smarty_tpl->tpl_vars['single']->value->class;?>
</td>
															<td><?php ob_start();
echo $_smarty_tpl->tpl_vars['invite']->value;
$_prefixVariable2 = ob_get_clean();
ob_start();
echo $_smarty_tpl->tpl_vars['single']->value->invite_num;
$_prefixVariable3 = ob_get_clean();
echo $_prefixVariable2-$_prefixVariable3;?>
</td>  
														</tr>
													<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
												</table>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
						
						
					</div>
				</div>
			</section>
		</div>
	</main>







<?php $_smarty_tpl->_subTemplateRender('file:user/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
