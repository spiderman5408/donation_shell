<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:49:22
  from '/www/wwwroot/sspanel/resources/views/material/user/node.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c551342b98007_75626671',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4de626f9e6bbac3219137d3db5859415e3781a0d' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/user/node.tpl',
      1 => 1549078638,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:dialog.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_5c551342b98007_75626671 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:user/main.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
 src="/assets/mi_js/canvasjs.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/assets/mi_js/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } <?php echo '</script'; ?>
>
<style>
  .text-overflow i{
    color:red;
    font-weight:solid;
    opacity: 0.5;
  }
</style>
	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<h1 class="content-heading">节点列表</h1>
			</div>
		</div>

		<div class="container">
			<section class="content-inner margin-top-no">
				<div class="ui-card-wrap">
					<div class="row">
						<div class="col-lg-12 col-sm-12">
							<div class="card">

								<div class="card-main">

									<div class="card-inner margin-bottom-no">
										<div class="tile-wrap">
								<p class="card-heading">免费节点</p> 
											<?php $_smarty_tpl->_assignInScope('id', 0);?>
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['node_prefix']->value, 'nodes', false, 'prefix');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['prefix']->value => $_smarty_tpl->tpl_vars['nodes']->value) {
?>
									<?php if ($_smarty_tpl->tpl_vars['node_isv6']->value[$_smarty_tpl->tpl_vars['prefix']->value] == 0 && $_smarty_tpl->tpl_vars['node_class']->value[$_smarty_tpl->tpl_vars['prefix']->value] == 0) {?>
												<?php $_smarty_tpl->_assignInScope('id', $_smarty_tpl->tpl_vars['id']->value+1);?>
                                           <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['nodes']->value, 'node');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['node']->value) {
?>

													<div class="tile tile-collapse" style="border-radius: 5px;">
														<div data-toggle="tile" data-target="#heading<?php echo $_smarty_tpl->tpl_vars['node_order']->value->{$_smarty_tpl->tpl_vars['prefix']->value};?>
">
															<div class="tile-side pull-left" data-ignore="tile">
                                                              
                                                                <p class="node-header-title" style="">
																	<?php if ($_smarty_tpl->tpl_vars['node_heartbeat']->value[$_smarty_tpl->tpl_vars['prefix']->value] == '在线') {?>
<span class="tag is-success" style="background-color: #23d160;color: #fff;padding: 0.25em 0.75em 0.25em 0.75em;border-radius: 5px;">在线</span>
<?php } else { ?>
<span class="tag is-success" style="background-color: #ff3860;color: #fff;padding: 0.25em 0.75em 0.25em 0.75em;border-radius: 5px;">维护</span>
<?php }?> </p>
																</div>
															
															<div class="tile-inner">
																<div class="text-overflow">
                                  <font color="#383838"><?php if ($_smarty_tpl->tpl_vars['config']->value["enable_flag"] == 'true') {?><img src="/images/prefix/<?php echo $_smarty_tpl->tpl_vars['node_flag_file']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
.png" onerror="javascript:this.src='/images/prefix/unknown.png';" height="22" width="40" /><?php }?> <?php echo $_smarty_tpl->tpl_vars['prefix']->value;?>
</font> | <?php if ($_smarty_tpl->tpl_vars['user']->value->class != 0) {?><font color="#ff9000"><i class="icon icon-lg">flight_takeoff</i></font> <strong><?php } else {
}?><b><font color="#474747"><?php echo $_smarty_tpl->tpl_vars['node_alive']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
</font></b></strong> | <font color="#ff9000"><i class="icon icon-lg">cloud</i></font>  <font color="#828282">负载：<?php echo $_smarty_tpl->tpl_vars['node_latestload']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
%</font> | <font color="#ff9000"><i class="icon icon-lg">import_export</i></font>  <font color="#828282"><?php echo $_smarty_tpl->tpl_vars['node_method']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
</font> | <font color="#ff9000"><i class="icon icon-lg">equalizer</i></font> <?php if (isset($_smarty_tpl->tpl_vars['node_bandwidth']->value[$_smarty_tpl->tpl_vars['prefix']->value]) == true) {?><font color="#aaaaaa"><?php echo $_smarty_tpl->tpl_vars['node_bandwidth']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
</font><?php } else { ?>N/A<?php }?> | <font color="#ff9000"><i class="icon icon-lg">network_check</i></font> <font color="#a5a5a5"><?php echo $_smarty_tpl->tpl_vars['node']->value->traffic_rate;?>
 倍率</font> | <font color="#ff9000"><i class="icon icon-lg">notifications_none</i></font> <font color="#c4c4c4"><?php echo $_smarty_tpl->tpl_vars['node']->value->status;?>
</font>
                                   </div>
															</div>
														</div>
														<div class="collapsible-region collapse" id="heading<?php echo $_smarty_tpl->tpl_vars['node_order']->value->{$_smarty_tpl->tpl_vars['prefix']->value};?>
">
															<div class="tile-sub">

																<br>



 																<?php if ($_smarty_tpl->tpl_vars['node']->value->node_class > $_smarty_tpl->tpl_vars['user']->value->class) {?>

																		<div class="card">
																		<div class="card-main">
																			<div class="card-inner">
																			<p class="card-heading" align="center"><b> <i class="icon icon-lg">visibility_off</i> <?php echo $_smarty_tpl->tpl_vars['user']->value->user_name;?>
，您无查看VIP节点权限，如需购买VIP请<a href="/user/shop">点击这里</a>。</b></p>
</div></div></div>
																			<?php } else { ?>
																	<?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
																	<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 10) {?>
																		<?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value->id,$_smarty_tpl->tpl_vars['user']->value->port,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
																	<?php }?>

																	<?php if ($_smarty_tpl->tpl_vars['node']->value->mu_only != 1 && $_smarty_tpl->tpl_vars['node']->value->sort != 11) {?>
																	<div class="card">
																		<div class="card-main">




																			<div class="card-inner">


																			<p class="card-heading" >
																				<a href="javascript:void(0);" onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value->id;?>
',0,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['node']->value->name;
if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?></a>
																				<span class="label label-brand-accent">←点击节点查看配置信息</span>
																			</p>

																			<p>备注：<?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</p>


																			 </div>
																		</div>
																	</div>
																	<?php }?>

																	<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 0 || $_smarty_tpl->tpl_vars['node']->value->sort == 10) {?>
																		<?php $_smarty_tpl->_assignInScope('point_node', $_smarty_tpl->tpl_vars['node']->value);?>
																	<?php }?>


																	<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 11) {?> 
																		<?php $_smarty_tpl->_assignInScope('server_explode', explode(";",$_smarty_tpl->tpl_vars['node']->value->server));?>
																		<div class="card">
																			<div class="card-main">
																				<div class="card-inner">
																					<p class="card-heading" >
																						<a href="javascript:void(0);" ><?php echo $_smarty_tpl->tpl_vars['node']->value->name;?>
</a>
																					</p>																				
																				<p>地址：<span class="label label-brand-accent">
                                                                                    <?php echo $_smarty_tpl->tpl_vars['server_explode']->value[0];?>

																				</span></p>

																				<p>端口：<span class="label label-brand-red">
																					<?php echo $_smarty_tpl->tpl_vars['server_explode']->value[1];?>

																				</span></p>

																				<p>协议参数：<span class="label label-green">
																					<?php echo $_smarty_tpl->tpl_vars['server_explode']->value[0];?>

																				</span></p>

																				<p>用户 UUID：<span class="label label-brand">
																					<?php echo $_smarty_tpl->tpl_vars['user']->value->getUuid();?>

																				</span></p>

																				<p>流量比例：<span class="label label-red">
																					<?php echo $_smarty_tpl->tpl_vars['node']->value->traffic_rate;?>

																				</span></p>

																				<p>AlterId：<span class="label label-green">
																					<?php echo $_smarty_tpl->tpl_vars['server_explode']->value[2];?>

																				</span></p>

																				<p>VMess链接：
																					<a class="copy-text" data-clipboard-text="<?php echo App\Utils\URL::getV2Url($_smarty_tpl->tpl_vars['user']->value,$_smarty_tpl->tpl_vars['node']->value);?>
">点击复制</a>
																				</p>

																				<p><?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</p>
																				</div>
																			</div>
																		</div>
																	<?php }?>
																	<?php if (($_smarty_tpl->tpl_vars['node']->value->sort == 0 || $_smarty_tpl->tpl_vars['node']->value->sort == 10) && $_smarty_tpl->tpl_vars['node']->value->custom_rss == 1 && $_smarty_tpl->tpl_vars['node']->value->mu_only != -1) {?>
																		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['node_muport']->value, 'single_muport');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['single_muport']->value) {
?>

																			<?php if (!($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_class <= $_smarty_tpl->tpl_vars['user']->value->class && ($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == 0 || $_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == $_smarty_tpl->tpl_vars['user']->value->node_group))) {?>
																				<?php continue 1;?>
																			<?php }?>

																			<?php if (!($_smarty_tpl->tpl_vars['single_muport']->value['user']->class >= $_smarty_tpl->tpl_vars['node']->value->node_class && ($_smarty_tpl->tpl_vars['node']->value->node_group == 0 || $_smarty_tpl->tpl_vars['single_muport']->value['user']->node_group == $_smarty_tpl->tpl_vars['node']->value->node_group))) {?>
																				<?php continue 1;?>
																			<?php }?>

																			<?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
																			<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 10 && $_smarty_tpl->tpl_vars['single_muport']->value['user']['is_multi_user'] != 2) {?>
																				<?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value->id,$_smarty_tpl->tpl_vars['single_muport']->value['server']->server,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
																			<?php }?>

																			<div class="card">
																				<div class="card-main">
																					<div class="card-inner">
																					<p class="card-heading" >
																						<a href="javascript:void(0);" onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value->id;?>
',<?php echo $_smarty_tpl->tpl_vars['single_muport']->value['server']->server;?>
,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['prefix']->value;?>
 <?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?> - 单端口 Shadowsocks - <?php echo $_smarty_tpl->tpl_vars['single_muport']->value['server']->server;?>
 端口</a>
																						<span class="label label-brand-accent"><?php echo $_smarty_tpl->tpl_vars['node']->value->status;?>
</span>
																					</p>




																					<p><?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</p>

																					 </div>
																				</div>
																			</div>
																		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
																	<?php }?>
																	<?php }?>
																<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>



																	<?php if (isset($_smarty_tpl->tpl_vars['point_node']->value)) {?>
																	<?php if ($_smarty_tpl->tpl_vars['point_node']->value != null) {?>

																		<div class="card">
																			<div class="card-main">
																				<div class="card-inner" id="info<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">

																				</div>
																			</div>
																		</div>

																		<?php echo '<script'; ?>
>
																		$().ready(function(){
																			$('#heading<?php echo $_smarty_tpl->tpl_vars['node_order']->value->{$_smarty_tpl->tpl_vars['prefix']->value};?>
').on("shown.bs.tile", function() {
																				$("#info<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
").load("/user/node/<?php echo $_smarty_tpl->tpl_vars['point_node']->value->id;?>
/ajax");
																			});
																		});
																		<?php echo '</script'; ?>
>
																	<?php }?>
																<?php }?>

																<?php $_smarty_tpl->_assignInScope('point_node', null);?>
															</div>
														</div>
												</div>
												<?php }?>

											<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>


								<p class="card-heading">VIP用户节点</p>

											<?php $_smarty_tpl->_assignInScope('id', 1000);?>
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['node_prefix']->value, 'nodes', false, 'prefix');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['prefix']->value => $_smarty_tpl->tpl_vars['nodes']->value) {
?>
										<?php if ($_smarty_tpl->tpl_vars['node_isv6']->value[$_smarty_tpl->tpl_vars['prefix']->value] == 0 && $_smarty_tpl->tpl_vars['node_class']->value[$_smarty_tpl->tpl_vars['prefix']->value] != 0) {?>
												<?php $_smarty_tpl->_assignInScope('id', $_smarty_tpl->tpl_vars['id']->value+1);?>
                                                          	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['nodes']->value, 'node');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['node']->value) {
?>

													<div class="tile tile-collapse" style="border-radius: 5px;">
														<div data-toggle="tile" data-target="#heading<?php echo $_smarty_tpl->tpl_vars['node_order']->value->{$_smarty_tpl->tpl_vars['prefix']->value};?>
">
															<div class="tile-side pull-left" data-ignore="tile">
                                                              
                                                                <p class="node-header-title" style="">
																	<?php if ($_smarty_tpl->tpl_vars['node_heartbeat']->value[$_smarty_tpl->tpl_vars['prefix']->value] == '在线') {?>
<span class="tag is-success" style="background-color: #23d160;color: #fff;padding: 0.25em 0.75em 0.25em 0.75em;border-radius: 5px;">在线</span>
<?php } else { ?>
<span class="tag is-success" style="background-color: #ff3860;color: #fff;padding: 0.25em 0.75em 0.25em 0.75em;border-radius: 5px;">维护</span>
<?php }?>
																</div>
															<div class="tile-inner">
																<div class="text-overflow">
                                                                  <font color="#383838"><?php if ($_smarty_tpl->tpl_vars['config']->value['enable_flag'] == 'true') {?><img src="/images/prefix/<?php echo $_smarty_tpl->tpl_vars['node_flag_file']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
.png" onerror="javascript:this.src='/images/prefix/unknown.png';" height="22" width="40" /><?php }?> <?php echo $_smarty_tpl->tpl_vars['prefix']->value;?>
</font> | <?php if ($_smarty_tpl->tpl_vars['user']->value->class != 0) {?><font color="#ff9000"><i class="icon icon-lg">flight_takeoff</i></font> <strong><?php } else {
}?><b><font color="#474747"><?php echo $_smarty_tpl->tpl_vars['node_alive']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
</font></b></strong> | <font color="#ff9000"><i class="icon icon-lg">cloud</i></font> <font color="#828282">负载：<?php echo $_smarty_tpl->tpl_vars['node_latestload']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
%</font> | <font color="#ff9000"><i class="icon icon-lg">import_export</i></font>  <font color="#828282"><?php echo $_smarty_tpl->tpl_vars['node_method']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
</font> | <font color="#ff9000"><i class="icon icon-lg">equalizer</i></font> <?php if (isset($_smarty_tpl->tpl_vars['node_bandwidth']->value[$_smarty_tpl->tpl_vars['prefix']->value]) == true) {?><font color="#aaaaaa"><?php echo $_smarty_tpl->tpl_vars['node_bandwidth']->value[$_smarty_tpl->tpl_vars['prefix']->value];?>
</font><?php } else { ?>N/A<?php }?> | <font color="#ff9000"><i class="icon icon-lg">network_check</i></font> <font color="#a5a5a5"><?php echo $_smarty_tpl->tpl_vars['node']->value->traffic_rate;?>
 倍率</font> | <font color="#ff9000"><i class="icon icon-lg">notifications_none</i></font> <font color="#c4c4c4"><?php echo $_smarty_tpl->tpl_vars['node']->value->status;?>
</font>
                                                                 </div>
															</div>
														</div>
														<div class="collapsible-region collapse" id="heading<?php echo $_smarty_tpl->tpl_vars['node_order']->value->{$_smarty_tpl->tpl_vars['prefix']->value};?>
">
															<div class="tile-sub">

																<br>



 																<?php if ($_smarty_tpl->tpl_vars['node']->value->node_class > $_smarty_tpl->tpl_vars['user']->value->class) {?>

																		<div class="card">
																		<div class="card-main">
																			<div class="card-inner">
																			<p class="card-heading" align="center"><b> <i class="icon icon-lg">visibility_off</i> <?php echo $_smarty_tpl->tpl_vars['user']->value->user_name;?>
，您无查看VIP节点权限，如需购买VIP请<a href="/user/shop">点击这里</a>。</b></p>
</div></div></div>
																			<?php } else { ?>
																	<?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
																	<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 10 && $_smarty_tpl->tpl_vars['node']->value->sort != 11) {?>
																		<?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value->id,$_smarty_tpl->tpl_vars['user']->value->port,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
																	<?php }?>

																	<?php if ($_smarty_tpl->tpl_vars['node']->value->mu_only != 1) {?>
																	<div class="card">
																		<div class="card-main">




																			<div class="card-inner">


																			<p class="card-heading" >
																				<a href="javascript:void(0);" onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value->id;?>
',0,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['node']->value->name;
if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?></a>
																				<span class="label label-brand-accent">←点击节点查看配置信息</span>
																			</p>

																			<p>备注：<?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</p>


																			 </div>
																		</div>
																	</div>
																	<?php }?>

																	<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 0 || $_smarty_tpl->tpl_vars['node']->value->sort == 10) {?>
																		<?php $_smarty_tpl->_assignInScope('point_node', $_smarty_tpl->tpl_vars['node']->value);?>
																	<?php }
if ($_smarty_tpl->tpl_vars['node']->value->sort == 11) {?> 
																		<?php $_smarty_tpl->_assignInScope('server_explode', explode(";",$_smarty_tpl->tpl_vars['node']->value->server));?>
																		<div class="card">
																			<div class="card-main">
																				<div class="card-inner">
																					<p class="card-heading" >
																						<a href="javascript:void(0);" ><?php echo $_smarty_tpl->tpl_vars['node']->value->name;?>
</a>
																					</p>
																				
																				<p>地址：<span class="label label-brand-accent">
                                                                                    <?php echo $_smarty_tpl->tpl_vars['server_explode']->value[0];?>

																				</span></p>

																				<p>端口：<span class="label label-brand-red">
																					<?php echo $_smarty_tpl->tpl_vars['server_explode']->value[1];?>

																				</span></p>

																				<p>协议参数：<span class="label label-green">
																					<?php echo $_smarty_tpl->tpl_vars['server_explode']->value[0];?>

																				</span></p>

																				<p>用户 UUID：<span class="label label-brand">
																					<?php echo $_smarty_tpl->tpl_vars['user']->value->getUuid();?>

																				</span></p>

																				<p>流量比例：<span class="label label-red">
																					<?php echo $_smarty_tpl->tpl_vars['node']->value->traffic_rate;?>

																				</span></p>

																				<p>AlterId：<span class="label label-green">
																					<?php echo $_smarty_tpl->tpl_vars['server_explode']->value[2];?>

																				</span></p>

																				<p>VMess链接：
																					<a class="copy-text" data-clipboard-text="<?php echo App\Utils\URL::getV2Url($_smarty_tpl->tpl_vars['user']->value,$_smarty_tpl->tpl_vars['node']->value);?>
">点击复制</a>
																				</p>

																				<p><?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</p>
																				</div>
																			</div>
																		</div>
																	<?php }?>


																	<?php if (($_smarty_tpl->tpl_vars['node']->value->sort == 0 || $_smarty_tpl->tpl_vars['node']->value->sort == 10) && $_smarty_tpl->tpl_vars['node']->value->custom_rss == 1 && $_smarty_tpl->tpl_vars['node']->value->mu_only != -1) {?>
																		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['node_muport']->value, 'single_muport');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['single_muport']->value) {
?>

																			<?php if (!($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_class <= $_smarty_tpl->tpl_vars['user']->value->class && ($_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == 0 || $_smarty_tpl->tpl_vars['single_muport']->value['server']->node_group == $_smarty_tpl->tpl_vars['user']->value->node_group))) {?>
																				<?php continue 1;?>
																			<?php }?>

																			<?php if (!($_smarty_tpl->tpl_vars['single_muport']->value['user']->class >= $_smarty_tpl->tpl_vars['node']->value->node_class && ($_smarty_tpl->tpl_vars['node']->value->node_group == 0 || $_smarty_tpl->tpl_vars['single_muport']->value['user']->node_group == $_smarty_tpl->tpl_vars['node']->value->node_group))) {?>
																				<?php continue 1;?>
																			<?php }?>

																			<?php $_smarty_tpl->_assignInScope('relay_rule', null);?>
																			<?php if ($_smarty_tpl->tpl_vars['node']->value->sort == 10 && $_smarty_tpl->tpl_vars['single_muport']->value['user']['is_multi_user'] != 2) {?>
																				<?php $_smarty_tpl->_assignInScope('relay_rule', $_smarty_tpl->tpl_vars['tools']->value->pick_out_relay_rule($_smarty_tpl->tpl_vars['node']->value->id,$_smarty_tpl->tpl_vars['single_muport']->value['server']->server,$_smarty_tpl->tpl_vars['relay_rules']->value));?>
																			<?php }?>

																			<div class="card">
																				<div class="card-main">
																					<div class="card-inner">
																					<p class="card-heading" >
																						<a href="javascript:void(0);" onClick="urlChange('<?php echo $_smarty_tpl->tpl_vars['node']->value->id;?>
',<?php echo $_smarty_tpl->tpl_vars['single_muport']->value['server']->server;?>
,<?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {
echo $_smarty_tpl->tpl_vars['relay_rule']->value->id;
} else { ?>0<?php }?>)"><?php echo $_smarty_tpl->tpl_vars['prefix']->value;?>
 <?php if ($_smarty_tpl->tpl_vars['relay_rule']->value != null) {?> - <?php echo $_smarty_tpl->tpl_vars['relay_rule']->value->dist_node()->name;
}?> - 单端口 Shadowsocks - <?php echo $_smarty_tpl->tpl_vars['single_muport']->value['server']->server;?>
 端口</a>
																						<span class="label label-brand-accent"><?php echo $_smarty_tpl->tpl_vars['node']->value->status;?>
</span>
																					</p>




																					<p><?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</p>

																					 </div>
																				</div>
																			</div>
																		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
																	<?php }?>
																	<?php }?>
																<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>



																	<?php if (isset($_smarty_tpl->tpl_vars['point_node']->value)) {?>
																	<?php if ($_smarty_tpl->tpl_vars['point_node']->value != null) {?>

																		<div class="card">
																			<div class="card-main">
																				<div class="card-inner" id="info<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">

																				</div>
																			</div>
																		</div>

																		<?php echo '<script'; ?>
>
																		$().ready(function(){
																			$('#heading<?php echo $_smarty_tpl->tpl_vars['node_order']->value->{$_smarty_tpl->tpl_vars['prefix']->value};?>
').on("shown.bs.tile", function() {
																				$("#info<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
").load("/user/node/<?php echo $_smarty_tpl->tpl_vars['point_node']->value->id;?>
/ajax");
																			});
																		});
																		<?php echo '</script'; ?>
>
																	<?php }?>
																<?php }?>

																<?php $_smarty_tpl->_assignInScope('point_node', null);?>
															</div>
														</div>
												</div>
												<?php }?>

											<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

										</div>
									</div>

								</div>
							</div>
							</div>

								<?php $_smarty_tpl->_subTemplateRender('file:dialog.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
						<div aria-hidden="true" class="modal modal-va-middle fade" id="nodeinfo" role="dialog" tabindex="-1">
							<div class="modal-dialog modal-full">
								<div class="modal-content">
									<iframe class="iframe-seamless" title="Modal with iFrame" id="infoifram"></iframe>
								</div>
							</div>
                          </div>
			</section>
		</div>
	</main>







<?php $_smarty_tpl->_subTemplateRender('file:user/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php echo '<script'; ?>
>
function urlChange(id,is_mu,rule_id) {
    var site = './node/'+id+'?ismu='+is_mu+'&relay_rule='+rule_id;
	if(id == 'guide')
	{
		var doc = document.getElementById('infoifram').contentWindow.document;
		doc.open();
		doc.write('<img src="../images/node.gif" style="width: 100%;height: 100%; border: none;"/>');
		doc.close();
	}
	else
	{
		document.getElementById('infoifram').src = site;
	}
	$("#nodeinfo").modal();
}

$(function(){
	new Clipboard('.copy-text');
});
$(".copy-text").click(function () {
	$("#result").modal();
	$("#msg").html("已复制，请进入软件添加。");
});
<?php echo '</script'; ?>
>
<?php }
}
