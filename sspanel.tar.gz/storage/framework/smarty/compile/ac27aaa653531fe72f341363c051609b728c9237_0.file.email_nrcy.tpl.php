<?php
/* Smarty version 3.1.34-dev-5, created on 2018-11-30 14:24:43
  from '/www/wwwroot/sspanel/resources/views/material/email_nrcy.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c00d7ab39aed9_04387838',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac27aaa653531fe72f341363c051609b728c9237' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/email_nrcy.tpl',
      1 => 1543557925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c00d7ab39aed9_04387838 (Smarty_Internal_Template $_smarty_tpl) {
?><ul>
	<img src="/images/email_nrcy.jpg" height="458" width="468">
	<br />
	<?php if ($_smarty_tpl->tpl_vars['config']->value["enable_admin_contact"] == 'true') {?>
	<p>如果发现“收信查询”中没有找到邮件，请联系站长：</p>
	<?php if ($_smarty_tpl->tpl_vars['config']->value["admin_contact1"] != null) {?>
	<li><?php echo $_smarty_tpl->tpl_vars['config']->value["admin_contact1"];?>
</li>
	<?php }?>
	<?php if ($_smarty_tpl->tpl_vars['config']->value["admin_contact2"] != null) {?>
	<li><?php echo $_smarty_tpl->tpl_vars['config']->value["admin_contact2"];?>
</li>
	<?php }?>
	<?php if ($_smarty_tpl->tpl_vars['config']->value["admin_contact3"] != null) {?>
	<li><?php echo $_smarty_tpl->tpl_vars['config']->value["admin_contact3"];?>
</li>
	<?php }?>
	<?php }?>
</ul><?php }
}
