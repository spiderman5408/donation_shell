<?php
/* Smarty version 3.1.34-dev-5, created on 2018-11-30 14:16:48
  from '/www/wwwroot/sspanel/resources/views/material/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c00d5d09951c4_44567374',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b4833ee11c909cfb9619055ab671caa424de39f2' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/header.tpl',
      1 => 1543557925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:crisp.tpl' => 1,
  ),
),false)) {
function content_5c00d5d09951c4_44567374 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
	<meta name="theme-color" content="#3f51b5">
	<title><?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
</title>
	<!-- css -->
	<link href="/theme/material/css/base.min.css" rel="stylesheet">
	<link href="/theme/material/css/project.min.css" rel="stylesheet">
	<link href="/theme/material/css/auth.css" rel="stylesheet">
    <link href="https://fonts.loli.net/css?family=Roboto:300,300italic,400,400italic,500,500italic|Material+Icons" rel="stylesheet">

	<!-- favicon -->

	<!-- ... -->
</head>
  <style>
.divcss5{ position:fixed; bottom:0;}
</style>
<body class="page-brand">
	
<?php if ($_smarty_tpl->tpl_vars['config']->value["enable_crisp"] == 'true') {
$_smarty_tpl->_subTemplateRender('file:crisp.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
}
