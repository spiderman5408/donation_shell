<?php
/* Smarty version 3.1.34-dev-5, created on 2019-02-02 11:48:38
  from '/www/wwwroot/sspanel/resources/views/material/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5c551316043749_62910148',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b4833ee11c909cfb9619055ab671caa424de39f2' => 
    array (
      0 => '/www/wwwroot/sspanel/resources/views/material/header.tpl',
      1 => 1543718590,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:crisp.tpl' => 1,
  ),
),false)) {
function content_5c551316043749_62910148 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
	<meta name="theme-color" content="#3271e5">
	<title><?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
</title>
	<!-- css -->
	<link href="/theme/material/css/base.min.css" rel="stylesheet">
	<link href="/theme/material/css/project.min.css" rel="stylesheet">
	<link href="https://fonts.loli.net/css?family=Roboto:300,300italic,400,400italic,500,500italic" rel="stylesheet">
	<link href="https://fonts.loli.net/css?family=Material+Icons" rel="stylesheet">

	<!-- favicon -->

	<!-- ... -->
</head>
  <style>
.divcss5{ position:fixed; bottom:0;}
</style>
<body class="page-brand" style="background-repeat:no-repeat; background-attachment:fixed;background-size:cover;background-image: url(https://tools.67cc.cn/bing/);">
	<header class="header header-transparent header-waterfall ui-header">
		<ul class="nav nav-list pull-left">
			<li>
				<a data-toggle="menu" href="/" style="color:white;">
					<span class="icon icon-lg">format_align_justify</span>
				</a>
			</li>
		</ul>

		<ul class="nav nav-list pull-right">
			<li class="dropdown margin-right">
				<a class="dropdown-toggle padding-left-no padding-right-no" data-toggle="dropdown">
				<?php if ($_smarty_tpl->tpl_vars['user']->value->isLogin) {?>
					<span class="access-hide"><?php echo $_smarty_tpl->tpl_vars['user']->value->user_name;?>
</span>
                	  <span class="icon icon-cd margin-right">account_circle</span>
				<!--	<span class="avatar avatar-sm"><img alt="alt text for John Smith avatar" src="<?php echo $_smarty_tpl->tpl_vars['user']->value->gravatar;?>
"></span>  -->
					</a>
					<ul class="dropdown-menu dropdown-menu-right">
						<li>
							<a class="padding-right-lg waves-attach" href="/user/"><span class="icon icon-lg margin-right">account_box</span>用户中心</a>
						</li>
						<li>
							<a class="padding-right-lg waves-attach" href="/user/logout"><span class="icon icon-lg margin-right">exit_to_app</span>登出</a>
						</li>
					</ul>
				<?php } else { ?>
					<span class="access-hide">未登录</span>
             			<span class="icon icon-cd margin-right" style="color:white;">account_circle</span>
				<!--	<span class="avatar avatar-sm"><img alt="alt text for John Smith avatar" src="/theme/material/images/users/avatar-001.jpg"></span> -->
					</a>
					<ul class="dropdown-menu dropdown-menu-right">
						<li>
							<a class="padding-right-lg waves-attach" href="/auth/login"><span class="icon icon-lg margin-right">vpn_key</span>登录</a>
						</li>
						<li>
							<a class="padding-right-lg waves-attach" href="/auth/register"><span class="icon icon-lg margin-right">person_add</span>注册</a>
						</li>
					</ul>
				<?php }?>

			</li>
		</ul>
	</header>
	
<?php if ($_smarty_tpl->tpl_vars['config']->value["enable_crisp"] == 'true') {
$_smarty_tpl->_subTemplateRender('file:crisp.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
}
