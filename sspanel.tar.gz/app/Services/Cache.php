<?php

namespace App\Services;

class Cache
{
}
