<?php

namespace App\Models;

class Lottery extends Model
{
    protected $connection = "default";
    protected $table = "lottery";
}
