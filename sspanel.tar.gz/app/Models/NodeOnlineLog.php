<?php


namespace App\Models;

class NodeOnlineLog extends Model
{
    protected $connection = "default";
    protected $table = "ss_node_online_log";
}
