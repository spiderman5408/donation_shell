<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/23 0023
 * Time: 下午 12:20
 */
define('BASE_PATH', __DIR__);
require BASE_PATH."/../../config/.config.php";
return [
    'db'=>[
        'db_host'=> $System_Config['db_host'],
        'db_name'=> $System_Config['db_database'],
        'db_user'=> $System_Config['db_username'],
        'db_pwd'=> $System_Config['db_password']
    ]
];